<!--搜索加分级测试版-->
<template>
  <div class="Online_digital_computer_room_panel">
    <div v-show="ifUpdate === '0'">
      <div class="grid-content bg-purple"><i class="el-icon-s-order" /><span>信息资源管理</span></div>
      <div class="app-container"  >
        <div>
          <el-row>
            <el-col :span="24">
              <div class="grid-content bg-purple-dark">
                <span style="color: #ffffff">线上数字机房</span>
              </div>
            </el-col>
          </el-row>
          <el-row
            :gutter="10"
            class="bg-condition"
          >
            <el-col
              :xs="2"
              :sm="2"
              :md="2"
              :lg="2"
              :xl="2"
            >
              <span>单位查询：</span>
            </el-col>
            <el-col
              :xs="3"
              :sm="3"
              :md="3"
              :lg="3"
              :xl="3"
            >
              <el-select
                v-model="dataName"
                placeholder="详细字段查询"
                multiple
                size="medium"
              >
                <el-option
                  v-for="(item,index) in basicValue"
                  :key="index"
                  :label="item.label"
                  :value="item.value"
                  class="searchInput"
                />

              </el-select>
            </el-col>
            <el-col
              :xs="3"
              :sm="3"
              :md="3"
              :lg="3"
              :xl="3"
            >
              <el-input
                v-model="inputValue"
                placeholder="输入查询内容"
                clearable
                size="medium"
              />
            </el-col>
            <el-col
              :xs="2"
              :sm="2"
              :md="2"
              :lg="2"
              :xl="2"
            >
              <el-button
                size="medium"
                type="primary"
                icon="el-icon-search"
                clearable="true"
                @click="searchData()"
              >查询</el-button>
            </el-col>
          </el-row>
        </div>
        <div class="main"  style='overflow: auto;position:relative;padding-bottom: 20px'>
          <dv-loading v-show='loading'>Loading...</dv-loading>
          <div class="card">
            <div class="roomCard" v-for="(item,index) in unit" >
              <dv-border-box-13>
                <div style=" height:70%; width:90%; position:absolute;left:1rem; top:1.5rem;" >
                  <el-col style="width: 35%;height: 100%;text-align: center;padding-top: 25px;">
                    <img :src=logoSrc+item.postId+logoImgetype style="width:4rem;border-radius: 4rem;position: relative;bottom: 0">
                  </el-col>
                  <el-col style="width: 65%;height: 100%">
                    <el-row style="width: 100%;height: 50%;text-align: center;padding-top: 20px;color: floralwhite">
                      {{item.postName}}
                    </el-row>
                    <el-row style="width: 100%;height: 50%;text-align: center;padding-top: 10px;">
                      <el-button type="primary" size="mini" @click="enterComputerRooms(item.postName)">进入机房群</el-button>
                    </el-row>
                  </el-col>
                </div>
              </dv-border-box-13>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-show="ifUpdate === '1'">
      <search-computer-room-by-post-name v-bind:postName="this.tempPost"></search-computer-room-by-post-name>
    </div>
  </div>
</template>

<script>
import {getPost} from "@/api/select";
import searchComputerRoomByPostName from "@/components/Infomanage/searchComputerRoomByPostName"
export default {
  name: 'digital_computer_room',
  components: {
    searchComputerRoomByPostName
  },
  data() {
    return{
      loading:true,
      ifUpdate: '0',
      unitAll:[],
      unit:[],
      logoSrc:'/unitLogo/',// logo放在public 文件夹下 使用绝对路径即可
      logoImgetype:'.png',
      dataName: 'all',
      inputValue: '',
      basicValue: [
        {
          value: 'postName',
          label: '所属单位'
        }
      ],
    };
  },
  mounted() {
    const data = {
      dataName:['111'],
      dataValue:'',
    }


    //--------------------获取单位开始-赵长开------------
    getPost().then(response => {
      this.loading = false
      this.unitAll = response.data.items
      this.unit = response.data.items
    })
    //--------------------获取单位结束-赵长开------------

  },
  methods:{
    //----------------------搜索功能searchData()实现开始--赵长开-----------------------------------------------------------
    searchData() {
      this.listLoading = true;
      this.unit = this.unitAll
      setTimeout(() => {
        let searchResults = [];
        if (this.inputValue !== '') {
          searchResults = this.unit.filter(data => {
            if(data.postName.includes(this.inputValue)){
              return (
                data.postName.includes(this.inputValue)
              )
            }
          });
        } else {
          searchResults = this.unit;
        }
        this.unit = searchResults;
        this.listLoading = false;
      }, 200);
    },
    //----------------------搜索功能searchData()实现结束-------------------------------------------------------------

    //--------------通过单位获取对应的全部机房--开始--赵长开------
    enterComputerRooms(postName){
      this.tempPost = postName
      this.ifUpdate = '1'
    },
  }
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
}
.main{
  width: 100%;
  height: 76.5vh;
  background: #041135;
  position: absolute;
  top: 0;
  bottom: 0;
  right: 0;
  left: 0;
}
.card{
  display:flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: left;
}
.roomCard{
  width: 18rem;
  height: 10rem;
  margin-left: 2rem;
  margin-top: 1rem;
}


::-webkit-scrollbar {
  width: 6px; /* 竖向滚动条宽度 */
  height: 6px; /* 横向滚动条高度 */
}
::-webkit-scrollbar-thumb {
  border-radius: 10px; /* 滚动条样式 */
  -webkit-box-shadow: #ffffff;  /* 内阴影 */
  background-color: #ffffff; /* 滚动条颜色 */
}

::-webkit-scrollbar-thumb:hover {
  background-color: #ffffff; /* 滚动条悬浮颜色 */
}

::-webkit-scrollbar-track-piece {
  background: #ffffff; /* 滚动条背景颜色 */
}

::-webkit-scrollbar-button {
  background-color: #ffffff; /* 定义两端按钮的样式 */
}

::-webkit-scrollbar-corner {
  background: #ffffff; /* 右下角重合处的样式*/
}


/* 单独设置悬浮颜色 */
::-webkit-scrollbar-thumb:vertical {
  background: #adaeb0;  /* 竖向滑块颜色 */
}
::-webkit-scrollbar-thumb:horizontal {
  background: #adaeb0; /* 横向滑块颜色 */
}

/* 单独设置滚动条背景色 */
::-webkit-scrollbar-track-piece:vertical {
  background: #ffffff;
}
::-webkit-scrollbar-track-piece:horizontal {
  background: #ffffff;
}


.bg-purple {
  background: #d3dce6;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
  padding: 9px;
  box-shadow: 0 0 4px rgb(0 0 0 / 30%);
}

</style>

<style lang="less" scoped>
*{
  font-size: 18px;
}
.app-container {
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}
.bg-purple-dark {
  background: #304156;
}
.bg-condition {
  line-height: 50px;
  text-align: center;
  height: 54px;
  margin: 0px !important;
  background: #d3dce6;
}
.searchInput {
  height: 40px;
  text-align: center;
  color: #0b0c10;
  background-color: #deecff;
}

.cardStyle{
  flex-direction: row;
  justify-content: space-around;
}
</style>
